<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SongController extends Controller
{
	public function searchForm() {

	}

	public function search() {

		// $track = new Track();

		// $results = $track->select('tracks.name AS track_name', 'composer', 'genres.name AS genre');

		// if( isset($track_name) && !empty($track_name) ) {
		// 	$results = $results->where('tracks.name', 'LIKE' , '%' . $track_name .'%');
		// }
		// if( isset($genre) && !empty($genre) ) {
		// 	$results = $results->where('tracks.genre_id', '=' , $genre);
		// }
		// $results = $results->leftJoin('genres', 'tracks.genre_id', '=', 'genres.genre_id');


		// return view('search_results', [
		// 	'tracks' => $results->get()
		// ]);

	}
}

?>